var mathlib = require('./mathlib'); 
console.log(mathlib);
mathlib.add(7,3);
mathlib.multiply(5,5);
mathlib.square(2);